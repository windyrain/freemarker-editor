import EventEmitter from 'events';

const _eventEmitter = new EventEmitter();

export default _eventEmitter;