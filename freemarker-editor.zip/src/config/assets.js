export const CUSTOME_ICONFONT = {
  folder: '&#xe623;',
  arrow: '&#xe8da;'
}